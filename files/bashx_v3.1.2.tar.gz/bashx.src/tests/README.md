# BashX Tests

Available _BashX_ **tests**.

You can run available **tests** with [`./bashx _run-tests`](../../bashx).
