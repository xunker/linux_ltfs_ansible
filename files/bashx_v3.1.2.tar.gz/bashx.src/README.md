# BashX example directory

## [/actions](actions)

_BashX_ example **actions**.
