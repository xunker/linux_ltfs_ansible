# BashX Framework Actions

Available _BashX_ **actions**.

> **Notes**
>
> - All scripts starting with `_` character, will be hidden when
>   `help` action is called.
